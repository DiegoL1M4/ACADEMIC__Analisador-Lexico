/* Analisador Léxico */

// Teste Code 3
try {
    numFloat = 10;
} catch(ae) {
    numFloat = 20;
} finally {
    numFloat = 30;
}

function testando() {
    if(teste) {
        for(j = 0; j < 1; j++) {
            while(teste) {
                numFloat = 10;
            }
        }
    }
    return true;
}