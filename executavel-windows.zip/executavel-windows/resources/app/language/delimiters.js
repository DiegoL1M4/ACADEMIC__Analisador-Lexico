
module.exports = delimiters = [
    ';', 
    ',',
    '(', 
    ')', 
    '[', 
    ']', 
    '{', 
    '}', 
    '"',
    '\''
];
