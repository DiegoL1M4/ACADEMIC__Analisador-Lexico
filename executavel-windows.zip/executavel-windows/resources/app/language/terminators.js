
module.exports = terminators = [
    ';', 
    ',',
    '(', 
    ')', 
    '[', 
    ']', 
    '{', 
    '}', 
    '"',
    '\''
];
