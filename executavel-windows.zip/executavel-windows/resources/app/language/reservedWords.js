
module.exports = reservedWord = [
    'class', 'super', 'var', 'let', 'instanceof', 'typeof', 'this', 'null',
    'with', 'delete', 'debugger', 'require',
    'if', 'else', 'for', 'of', 'while', 'do', 'switch', 'case', 'default', 'break', 'continue',
    'try', 'catch', 'throw', 'finally',
    'function', 'return', 'true', 'false'
];
