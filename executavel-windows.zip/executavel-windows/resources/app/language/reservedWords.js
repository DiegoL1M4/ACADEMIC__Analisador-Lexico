
module.exports = reservedWord = [
    'class', 'super', 'var', 'let', 'instanceof', 'typeof', 'this',
    'import', 'new', 'extends', 'yield', 'void', 'interface', 'enum',
    'with', 'delete', 'debugger', 'require', 'const', 'enum', 'in',
    'if', 'else', 'for', 'of', 'while', 'do',
    'switch', 'case', 'default', 'break', 'continue',
    'try', 'catch', 'throw', 'finally',
    'function', 'return', 'true', 'false', 'null'
];
