/* Analisador Léxico */

// Teste Code 3
try {
    numFloat -= 10;
} catch(ae) {
    console.log("ok");
} finally {
    console.log("ok");
}

function testando() {
    if(numFloat >= numInt) {
        for(j = 0; j < 1; j++) {
            while(numFloat > numInt) {
                xy = [[1],[2],[3]];
            }
        }
    }
    return true;
}