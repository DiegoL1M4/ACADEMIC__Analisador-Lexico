/* Analisador Léxico */

// Teste Code 2
for(j = 0; j < 1; j++) {
    x = [1,2,3];
}

while(numFloat > numInt) {
    xy = [[1],[2],[3]];
}

do {
    numFloat += 5;
} while(numFloat < numInt);

switch(numFloat) {
    case 'a':
        break;

    default:
        continue;
}